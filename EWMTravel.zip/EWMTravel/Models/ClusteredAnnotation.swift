//
//  ClusteredAnnotation.swift
//  EWMTravel
//
//  Created by Юрий Мартыненко on 27.06.2024.
//

import Foundation
import MapKit


class ClusteredAnnotation: NSObject, MKAnnotation {
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    var annotations: [MKAnnotation]
    
    init(coordinate: CLLocationCoordinate2D, title: String? = nil, subtitle: String? = nil, annotations: [MKAnnotation]) {
        self.coordinate = coordinate
        self.title = "\(annotations.count) annotations"
        self.subtitle = nil
        self.annotations = annotations
    }
}

